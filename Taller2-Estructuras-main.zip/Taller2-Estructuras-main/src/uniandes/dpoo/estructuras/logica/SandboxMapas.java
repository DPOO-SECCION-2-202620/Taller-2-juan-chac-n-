package uniandes.dpoo.estructuras.logica;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Esta clase tiene un conjunto de métodos para practicar operaciones sobre mapas.
 *
 * Todos los métodos deben operar sobre el atributo mapaCadenas que se declara como un Map.
 */
public class SandboxMapas
{
    /**
     * Un mapa de cadenas para realizar varias de las siguientes operaciones.
     */
    private Map<String, String> mapaCadenas;

    /**
     * Crea una nueva instancia de la clase con el mapa vacío.
     */
    public SandboxMapas( )
    {
        mapaCadenas = new HashMap<String, String>( );
    }

    /**
     * Retorna una lista con los valores del mapa ordenados lexicográficamente.
     */
    public List<String> getValoresComoLista( )
    {
        List<String> valores = new ArrayList<String>( );

        for( String valor : mapaCadenas.values( ) )
        {
            valores.add( valor );
        }

        Collections.sort( valores );

        return valores;
    }

    /**
     * Retorna una lista con las llaves ordenadas lexicográficamente de mayor a menor.
     */
    public List<String> getLlavesComoListaInvertida( )
    {
        List<String> llaves = new ArrayList<String>( );

        for( String llave : mapaCadenas.keySet( ) )
        {
            llaves.add( llave );
        }

        Collections.sort( llaves );
        Collections.reverse( llaves );

        return llaves;
    }

    /**
     * Retorna la llave lexicográficamente menor.
     */
    public String getPrimera( )
    {
        if( mapaCadenas.isEmpty( ) )
        {
            return null;
        }

        String primera = null;

        for( String llave : mapaCadenas.keySet( ) )
        {
            if( primera == null || llave.compareTo( primera ) < 0 )
            {
                primera = llave;
            }
        }

        return primera;
    }

    /**
     * Retorna el valor lexicográficamente mayor.
     */
    public String getUltima( )
    {
        if( mapaCadenas.isEmpty( ) )
        {
            return null;
        }

        String ultima = null;

        for( String valor : mapaCadenas.values( ) )
        {
            if( ultima == null || valor.compareTo( ultima ) > 0 )
            {
                ultima = valor;
            }
        }

        return ultima;
    }

    /**
     * Retorna las llaves del mapa convertidas a mayúsculas.
     */
    public Collection<String> getLlaves( )
    {
        List<String> llaves = new ArrayList<String>( );

        for( String llave : mapaCadenas.keySet( ) )
        {
            llaves.add( llave.toUpperCase( ) );
        }

        return llaves;
    }

    /**
     * Retorna la cantidad de valores diferentes en el mapa.
     */
    public int getCantidadCadenasDiferentes( )
    {
        List<String> valores = new ArrayList<String>( );

        for( String valor : mapaCadenas.values( ) )
        {
            if( !valores.contains( valor ) )
            {
                valores.add( valor );
            }
        }

        return valores.size( );
    }

    /**
     * Agrega una cadena al mapa.
     * La llave es la cadena invertida.
     */
    public void agregarCadena( String cadena )
    {
        String llave = "";

        for( int i = cadena.length( ) - 1; i >= 0; i-- )
        {
            llave = llave + cadena.charAt( i );
        }

        mapaCadenas.put( llave, cadena );
    }

    /**
     * Elimina una cadena dada la llave.
     */
    public void eliminarCadenaConLLave( String llave )
    {
        mapaCadenas.remove( llave );
    }

    /**
     * Elimina una cadena dado el valor.
     */
    public void eliminarCadenaConValor( String valor )
    {
        String llaveEncontrada = null;

        for( String llave : mapaCadenas.keySet( ) )
        {
            if( mapaCadenas.get( llave ).equals( valor ) )
            {
                llaveEncontrada = llave;
                break;
            }
        }

        if( llaveEncontrada != null )
        {
            mapaCadenas.remove( llaveEncontrada );
        }
    }

    /**
     * Reinicia el mapa con las representaciones como Strings.
     */
    public void reiniciarMapaCadenas( List<Object> objetos )
    {
        mapaCadenas.clear( );

        for( Object objeto : objetos )
        {
            agregarCadena( objeto.toString( ) );
        }
    }

    /**
     * Modifica las llaves del mapa para ponerlas en mayúsculas.
     * Los valores se mantienen iguales.
     */
    public void volverMayusculas( )
    {
        Map<String, String> nuevoMapa = new HashMap<String, String>( );

        for( String llave : mapaCadenas.keySet( ) )
        {
            String nuevaLlave = llave.toUpperCase( );
            String valor = mapaCadenas.get( llave );

            nuevoMapa.put( nuevaLlave, valor );
        }

        mapaCadenas.clear( );
        mapaCadenas.putAll( nuevoMapa );
    }

    /**
     * Verifica si todos los elementos del arreglo hacen parte de los valores del mapa.
     */
    public boolean compararValores( String[] otroArreglo )
    {
        for( String valor : otroArreglo )
        {
            if( !mapaCadenas.containsValue( valor ) )
            {
                return false;
            }
        }

        return true;
    }
}
