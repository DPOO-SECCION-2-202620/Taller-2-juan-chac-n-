package uniandes.dpoo.estructuras.logica;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

/**
 * Esta clase tiene un conjunto de métodos para practicar operaciones sobre listas de enteros y de cadenas.
 *
 * Todos los métodos deben operar sobre los atributos listaEnteros y listaCadenas.
 * 
 * No pueden agregarse nuevos atributos.
 * 
 * Implemente los métodos usando operaciones sobre listas.
 * 
 * Intente usar varias formas de recorrer las listas.
 */
public class SandboxListas
{
    /**
     * Una lista de enteros para realizar varias de las siguientes operaciones.
     */
    private List<Integer> listaEnteros;

    /**
     * Una lista de cadenas para realizar varias de las siguientes operaciones
     */
    private List<String> listaCadenas;

    /**
     * Crea una nueva instancia de la clase con las dos listas inicializadas pero vacías
     */
    public SandboxListas( )
    {
        listaEnteros = new ArrayList<Integer>( );
        listaCadenas = new LinkedList<String>( );
    }

    /**
     * Retorna una copia de la lista de enteros.
     */
    public List<Integer> getCopiaEnteros( )
    {
        List<Integer> copia = new ArrayList<Integer>( );

        for( Integer entero : listaEnteros )
        {
            copia.add( entero );
        }

        return copia;
    }

    /**
     * Retorna una copia de la lista de cadenas.
     */
    public List<String> getCopiaCadenas( )
    {
        List<String> copia = new LinkedList<String>( );

        for( String cadena : listaCadenas )
        {
            copia.add( cadena );
        }

        return copia;
    }

    /**
     * Retorna un arreglo con los valores de la lista de enteros.
     */
    public int[] getEnterosComoArreglo( )
    {
        int[] arreglo = new int[listaEnteros.size( )];

        for( int i = 0; i < listaEnteros.size( ); i++ )
        {
            arreglo[i] = listaEnteros.get( i );
        }

        return arreglo;
    }

    /**
     * Retorna la cantidad de valores en la lista de enteros.
     */
    public int getCantidadEnteros( )
    {
        return listaEnteros.size( );
    }

    /**
     * Retorna la cantidad de valores en la lista de cadenas.
     */
    public int getCantidadCadenas( )
    {
        return listaCadenas.size( );
    }

    /**
     * Agrega un nuevo valor al final de la lista de enteros.
     */
    public void agregarEntero( int entero )
    {
        listaEnteros.add( entero );
    }

    /**
     * Agrega un nuevo valor al final de la lista de cadenas.
     */
    public void agregarCadena( String cadena )
    {
        listaCadenas.add( cadena );
    }

    /**
     * Elimina todas las apariciones de un determinado valor dentro de la lista de enteros.
     */
    public void eliminarEntero( int valor )
    {
        while( listaEnteros.contains( valor ) )
        {
            listaEnteros.remove( Integer.valueOf( valor ) );
        }
    }

    /**
     * Elimina todas las apariciones de un determinado valor dentro de la lista de cadenas.
     */
    public void eliminarCadena( String cadena )
    {
        while( listaCadenas.contains( cadena ) )
        {
            listaCadenas.remove( cadena );
        }
    }

    /**
     * Inserta un nuevo entero en la lista de enteros.
     */
    public void insertarEntero( int entero, int posicion )
    {
        if( posicion < 0 )
        {
            posicion = 0;
        }

        if( posicion > listaEnteros.size( ) )
        {
            posicion = listaEnteros.size( );
        }

        listaEnteros.add( posicion, entero );
    }

    /**
     * Elimina un valor de la lista de enteros dada su posición.
     */
    public void eliminarEnteroPorPosicion( int posicion )
    {
        if( posicion >= 0 && posicion < listaEnteros.size( ) )
        {
            listaEnteros.remove( posicion );
        }
    }

    /**
     * Reinicia la lista de enteros con los valores truncados.
     */
    public void reiniciarArregloEnteros( double[] valores )
    {
        listaEnteros.clear( );

        for( int i = 0; i < valores.length; i++ )
        {
            listaEnteros.add( ( int ) valores[i] );
        }
    }

    /**
     * Reinicia la lista de cadenas con las representaciones como Strings.
     */
    public void reiniciarArregloCadenas( List<Object> objetos )
    {
        listaCadenas.clear( );

        for( Object objeto : objetos )
        {
            listaCadenas.add( objeto.toString( ) );
        }
    }

    /**
     * Modifica la lista de enteros para que todos los valores sean positivos.
     */
    public void volverPositivos( )
    {
        for( int i = 0; i < listaEnteros.size( ); i++ )
        {
            int valor = listaEnteros.get( i );

            if( valor < 0 )
            {
                listaEnteros.set( i, valor * -1 );
            }
        }
    }

    /**
     * Modifica la lista de enteros para que queden organizados de MAYOR a MENOR.
     */
    public void organizarEnteros( )
    {
        for( int i = 0; i < listaEnteros.size( ) - 1; i++ )
        {
            for( int j = i + 1; j < listaEnteros.size( ); j++ )
            {
                if( listaEnteros.get( j ) > listaEnteros.get( i ) )
                {
                    int temporal = listaEnteros.get( i );

                    listaEnteros.set( i, listaEnteros.get( j ) );
                    listaEnteros.set( j, temporal );
                }
            }
        }
    }

    /**
     * Modifica la lista de cadenas para que queden organizadas lexicográficamente.
     */
    public void organizarCadenas( )
    {
        for( int i = 0; i < listaCadenas.size( ) - 1; i++ )
        {
            for( int j = i + 1; j < listaCadenas.size( ); j++ )
            {
                if( listaCadenas.get( j ).compareTo( listaCadenas.get( i ) ) < 0 )
                {
                    String temporal = listaCadenas.get( i );

                    listaCadenas.set( i, listaCadenas.get( j ) );
                    listaCadenas.set( j, temporal );
                }
            }
        }
    }

    /**
     * Cuenta cuántas veces aparece el valor recibido.
     */
    public int contarApariciones( int valor )
    {
        int cantidad = 0;

        for( Integer entero : listaEnteros )
        {
            if( entero == valor )
            {
                cantidad++;
            }
        }

        return cantidad;
    }

    /**
     * Cuenta cuántas veces aparece la cadena recibida.
     * La búsqueda no diferencia entre mayúsculas y minúsculas.
     */
    public int contarApariciones( String cadena )
    {
        int cantidad = 0;

        for( String elemento : listaCadenas )
        {
            if( elemento.equalsIgnoreCase( cadena ) )
            {
                cantidad++;
            }
        }

        return cantidad;
    }

    /**
     * Cuenta cuántos valores diferentes aparecen más de una vez.
     */
    public int contarEnterosRepetidos( )
    {
        int cantidad = 0;

        for( int i = 0; i < listaEnteros.size( ); i++ )
        {
            int valor = listaEnteros.get( i );

            if( listaEnteros.indexOf( valor ) == i )
            {
                if( contarApariciones( valor ) > 1 )
                {
                    cantidad++;
                }
            }
        }

        return cantidad;
    }

    /**
     * Compara la lista de enteros con un arreglo de enteros.
     */
    public boolean compararArregloEnteros( int[] otroArreglo )
    {
        if( listaEnteros.size( ) != otroArreglo.length )
        {
            return false;
        }

        for( int i = 0; i < listaEnteros.size( ); i++ )
        {
            if( listaEnteros.get( i ) != otroArreglo[i] )
            {
                return false;
            }
        }

        return true;
    }

    /**
     * Genera una nueva serie de enteros aleatorios.
     */
    public void generarEnteros( int cantidad, int minimo, int maximo )
    {
        listaEnteros.clear( );

        for( int i = 0; i < cantidad; i++ )
        {
            int valor = ( int )( Math.random( ) * ( maximo - minimo + 1 ) ) + minimo;

            listaEnteros.add( valor );
        }
    }
}