package uniandes.dpoo.estructuras.logica;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.NavigableSet;
import java.util.TreeSet;

/**
 * Esta clase tiene un conjunto de métodos para practicar operaciones sobre conjuntos implementados usando un árbol (TreeSet).
 */
public class SandboxConjuntos
{
    /**
     * Un conjunto de cadenas para realizar varias de las siguientes operaciones.
     */
    private NavigableSet<String> arbolCadenas;

    /**
     * Crea una nueva instancia de la clase con el conjunto vacío.
     */
    public SandboxConjuntos( )
    {
        arbolCadenas= new TreeSet<String>( );
    }

    /**
     * Retorna una lista con las cadenas ordenadas lexicográficamente.
     */
    public List<String> getCadenasComoLista( )
    {
        List<String> lista = new ArrayList<String>( );

        for( String cadena : arbolCadenas )
        {
            lista.add( cadena );
        }

        return lista;
    }

    /**
     * Retorna una lista con las cadenas ordenadas de mayor a menor.
     */
    public List<String> getCadenasComoListaInvertida( )
    {
        List<String> lista= new ArrayList<String>( );

        for( String cadena: arbolCadenas.descendingSet( ) )
        {
            lista.add( cadena );
        }

        return lista;
    }

    /**
     * Retorna la cadena lexicográficamente menor.
     */
    public String getPrimera( )
    {
        if( arbolCadenas.isEmpty( ) )
        {
            return null;
        }

        return arbolCadenas.first( );
    }

    /**
     * Retorna la cadena lexicográficamente mayor.
     */
    public String getUltima( )
    {
        if( arbolCadenas.isEmpty( ) )
        {
            return null;
        }

        return arbolCadenas.last( );
    }

    /**
     * Retorna las cadenas mayores o iguales a la cadena dada.
     */
    public Collection<String> getSiguientes(String cadena)
    {
        return arbolCadenas.tailSet( cadena, true );
    }

    /**
     * Retorna la cantidad de valores.
     */
    public int getCantidadCadenas( )
    {
        return arbolCadenas.size( );
    }

    /**
     * Agrega una cadena al conjunto.
     */
    public void agregarCadena(String cadena)
    {
        arbolCadenas.add(cadena);
    }

    /**
     * Elimina una cadena del conjunto.
     */
    public void eliminarCadena(String cadena)
    {
        arbolCadenas.remove(cadena);
    }

    /**
     * Elimina una cadena sin importar mayúsculas o minúsculas.
     */
    public void eliminarCadenaSinMayusculasOMinusculas(String cadena)
    {
        String cadenaEncontrada = null;

        for( String elemento:arbolCadenas)
        {
            if( elemento.equalsIgnoreCase(cadena) )
            {
                cadenaEncontrada= elemento;
                break;
            }
        }

        if( cadenaEncontrada!=null )
        {
            arbolCadenas.remove(cadenaEncontrada);
        }
    }

    /**
     * Elimina la primera cadena del conjunto.
     */
    public void eliminarPrimera( )
    {
        if( !arbolCadenas.isEmpty( ) )
        {
            arbolCadenas.pollFirst( );
        }
    }

    /**
     * Reinicia el conjunto con las representaciones como Strings.
     */
    public void reiniciarConjuntoCadenas( List<Object> objetos )
    {
        arbolCadenas.clear( );

        for( Object objeto : objetos )
        {
            arbolCadenas.add( objeto.toString( ) );
        }
    }

    /**
     * Convierte todas las cadenas a mayúsculas.
     */
    public void volverMayusculas( )
    {
        List<String> cadenas = new ArrayList<String>( arbolCadenas );

        arbolCadenas.clear( );

        for( String cadena : cadenas )
        {
            arbolCadenas.add( cadena.toUpperCase( ) );
        }
    }

    /**
     * Construye un árbol de cadenas organizadas de mayor a menor.
     */
    public TreeSet<String> invertirCadenas( )
    {
        TreeSet<String> invertido = new TreeSet<String>( );

        for( String cadena : arbolCadenas )
        {
            invertido.add( cadena );
        }

        return ( TreeSet<String> ) invertido.descendingSet( );
    }

    /**
     * Verifica si todos los elementos del arreglo hacen parte del conjunto.
     */
    public boolean compararElementos( String[] otroArreglo )
    {
        for( String cadena : otroArreglo )
        {
            if( !arbolCadenas.contains( cadena ) )
            {
                return false;
            }
        }

        return true;
    }
}